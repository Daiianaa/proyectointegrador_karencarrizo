package com.portafolio.kc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KcApplicationTests {

	@Test
	void contextLoads() {
	}

}
