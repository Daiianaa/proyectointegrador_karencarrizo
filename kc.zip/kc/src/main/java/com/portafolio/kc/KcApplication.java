package com.portafolio.kc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KcApplication {

	public static void main(String[] args) {
		SpringApplication.run(KcApplication.class, args);
	}

}
